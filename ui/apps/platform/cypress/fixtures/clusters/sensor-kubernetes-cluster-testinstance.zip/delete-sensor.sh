#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)"

kubectl delete -f "$DIR/sensor.yaml"
kubectl delete -n stackrox secret sensor-tls benchmark-tls additional-ca-sensor
kubectl delete -f "$DIR/sensor-rbac.yaml"


kubectl -n stackrox delete secret collector-tls collector-stackrox




if ! kubectl get -n stackrox deploy/central; then
    kubectl delete -n stackrox secret stackrox

fi
